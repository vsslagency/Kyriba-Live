import React, { Component } from 'react'
import { Controller, Scene } from 'react-scrollmagic'
import { Tween, Timeline } from 'react-gsap'


import "./App.css"
import Header from './components/Header'
import Event from './components/Event'
import Footer from './components/Footer'


export default class App extends Component {
  render() {
    return (
      <div className="home">
        <Header />
        <Event />
        <Footer />
      </div >
    )
  }
}


