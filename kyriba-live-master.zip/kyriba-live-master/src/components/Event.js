import React, { Component } from 'react'

export default class Event extends Component {
  render() {
    return (
      <section className="events">
        <div className="container">

          <div className="event-container row align-items-center event-img-tokyo">
            <div className="col-md-8">
              <h2>Tokyo
                <span className="d-block">July 9, 2019</span>
              </h2>

            </div>
            <div className="col-md-4">
              <div className="btn btn-primary btn-block">
                <a href="https://kyribalive.com/jp/" target="_blank">Learn More</a>
              </div>
            </div>
          </div>

          <div className="event-container row align-items-center event-img-paris">
            <div className="col-md-8">
              <h2>Paris
                <span class="d-block">October 10, 2019</span>
              </h2>

            </div>
            <div className="col-md-4">
              <div className="btn btn-primary btn-block">
                <a href="https://kyribalive.com/fr-en/" target="_blank">Learn More</a>
              </div>
            </div>

          </div>

          <div className="event-container row align-items-center event-img-vegas">
            <div className="col-md-8">
              <h2>Las Vegas
                <span class="d-block">Just Completed</span>
              </h2>

            </div>
            <div className="col-md-4">
              <div className="btn btn-primary btn-block">
                <a href="https://kyribalive.com/us/" target="_blank">View Highlights</a>
              </div>
            </div>

          </div>

          <div className="event-container row align-items-center event-img-london">
            <div className="col-md-8">
              <h2>London
                <span class="d-block">Just Completed</span>
              </h2>

            </div>
            <div className="col-md-4">
              <div className="btn btn-primary btn-block">
                <a href="https://kyribalive.com/uk/" target="_blank">View Highlights</a>
              </div>
            </div>

          </div>
        </div>
      </section>
    )
  }
}
