import React, { Component } from 'react'
import IcoMoon from 'react-icomoon';

export default class Footer extends Component {
  render() {
    return (
      <footer>
        <div className="footer-social">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12">
                <ul className="social-icons text-center mx-auto py-4 justify-content-center">
                  <li><a href="https://www.facebook.com/Kyriba" target="_blank"><IcoMoon icon="facebook" className="icon-facebook" /></a></li>
                  <li><a href="https://twitter.com/kyribacorp" target="_blank"><IcoMoon icon="twitter" className="icon-twitter" /></a></li>
                  <li><a href="https://twitter.com/kyribacorp" target="_blank"><IcoMoon icon="youtube" className="icon-youtube" /></a></li>
                  <li><a href="https://www.linkedin.com/company/kyriba" target="_blank"><IcoMoon icon="linkedin" className="icon-linkedin" /></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="footer-main">
          <div className="container">
            <div className="copyright row">
              <div className="col-12">
                <p>Copyright © 2019 Kyriba Corp. All rights reserved. Kyriba and the "kyriba" logo are registered trademarks of Kyriba Corp.</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    )
  }
}
