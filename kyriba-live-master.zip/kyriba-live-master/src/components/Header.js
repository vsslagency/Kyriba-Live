import React, { Component } from 'react'
import logo from '../images/logo.svg'

export default class Header extends Component {
  render() {
    return (
      <div>
        <header id="header">
          <div className="banner">
            <div className="container">
              <div className="row">
                <div className="col-12 mx-auto">
                  <a href="https://kyribalive.com"></a>
                  <img className="logo img-fluid d-block mx-auto"
                    src={logo}
                    alt="Kyriba logo"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="banner-sub">
            <div className="container">
              <h2>2019 Events Schedule</h2>


            </div>
          </div>


        </header>
      </div>
    )
  }
}
